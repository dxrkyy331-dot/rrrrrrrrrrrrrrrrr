package com.example.client.gui;

import com.example.client.category.Category;
import com.example.client.module.Module;
import com.example.client.module.ModuleManager;
import com.example.client.setting.BooleanSetting;
import com.example.client.setting.ModeSetting;
import com.example.client.setting.NumberSetting;
import com.example.client.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Przejrzyste, nowoczesne i profesjonalne menu ClickGUI.
 * - Czysta, czytelna czcionka Minecraft bez zbędnych emotek
 * - Elegancki, ciemny motyw z neonowym akcentem Cyan
 * - Płynne przewijanie, wyszukiwarka oraz przejrzyste suwaki i przełączniki
 */
public class RockstarClickGuiScreen extends Screen {

    private final int guiWidth = 580;
    private final int guiHeight = 360;
    private int guiX;
    private int guiY;

    private Category currentCategory = Category.COMBAT;
    private int scrollOffset = 0;
    private int maxScroll = 0;

    private String searchQuery = "";
    private boolean searchFocused = false;

    private Module listeningModule = null;
    private NumberSetting draggingSlider = null;
    private int draggingSliderX = 0;
    private int draggingSliderWidth = 0;

    public RockstarClickGuiScreen() {
        super(Component.literal("ClickGUI"));
    }

    @Override
    protected void init() {
        super.init();
        this.guiX = (this.width - this.guiWidth) / 2;
        this.guiY = (this.height - this.guiHeight) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        // Ciemne tło za oknem
        RenderUtils.drawRect(graphics, 0, 0, this.width, this.height, 0x85000000);

        // Główne okno GUI
        RenderUtils.drawRect(graphics, guiX, guiY, guiWidth, guiHeight, 0xF5111317);
        RenderUtils.drawOutline(graphics, guiX, guiY, guiWidth, guiHeight, 1, 0xFF1E2129);

        // 1. Pasek górny (Header)
        int headerH = 38;
        RenderUtils.drawRect(graphics, guiX, guiY, guiWidth, headerH, 0xFF0D0E12);
        RenderUtils.drawRect(graphics, guiX, guiY + headerH - 1, guiWidth, 1, 0xFF1E2129);

        // Tytuł klienta
        graphics.drawString(this.font, "Rockstar", guiX + 14, guiY + 15, 0xFF00D2FF, false);
        graphics.drawString(this.font, "Client", guiX + 64, guiY + 15, 0xFF8A93A6, false);

        // Pole wyszukiwania
        int searchW = 140;
        int searchH = 20;
        int searchX = guiX + guiWidth - searchW - 14;
        int searchY = guiY + 9;

        int searchBg = searchFocused ? 0xFF171A21 : 0xFF12141A;
        int searchBorder = searchFocused ? 0xFF00D2FF : 0xFF252934;
        RenderUtils.drawRect(graphics, searchX, searchY, searchW, searchH, searchBg);
        RenderUtils.drawOutline(graphics, searchX, searchY, searchW, searchH, 1, searchBorder);

        String searchDisplay = searchQuery.isEmpty() ? (searchFocused ? "" : "Szukaj...") : searchQuery;
        int searchCol = searchQuery.isEmpty() ? 0xFF5A6275 : 0xFFFFFFFF;
        graphics.drawString(this.font, searchDisplay, searchX + 6, searchY + 6, searchCol, false);

        if (!searchQuery.isEmpty()) {
            graphics.drawString(this.font, "x", searchX + searchW - 12, searchY + 5, 0xFF8A93A6, false);
        }

        // 2. Boczny pasek kategorii (Sidebar)
        int sidebarW = 125;
        int sidebarX = guiX;
        int sidebarY = guiY + headerH;
        int sidebarH = guiHeight - headerH;

        RenderUtils.drawRect(graphics, sidebarX, sidebarY, sidebarW, sidebarH, 0xFF0E0F14);
        RenderUtils.drawRect(graphics, sidebarX + sidebarW - 1, sidebarY, 1, sidebarH, 0xFF1E2129);

        int catY = sidebarY + 8;
        for (Category category : Category.values()) {
            boolean isSelected = (this.currentCategory == category);
            boolean isHovered = RenderUtils.isHovered(mouseX, mouseY, sidebarX + 6, catY, sidebarW - 12, 28);

            int catBg = isSelected ? 0xFF161922 : (isHovered ? 0xFF12141B : 0x00000000);
            if (catBg != 0) {
                RenderUtils.drawRect(graphics, sidebarX + 6, catY, sidebarW - 12, 28, catBg);
            }

            if (isSelected) {
                // Lewy wskaźnik aktywnej kategorii
                RenderUtils.drawRect(graphics, sidebarX + 6, catY, 2, 28, 0xFF00D2FF);
            }

            int catTextCol = isSelected ? 0xFFFFFFFF : (isHovered ? 0xFFC7CDDB : 0xFF71788A);
            graphics.drawString(this.font, category.getDisplayName(), sidebarX + 16, catY + 10, catTextCol, false);

            catY += 32;
        }

        // 3. Zawartość kategorii (Moduły)
        int contentX = guiX + sidebarW + 10;
        int contentY = guiY + headerH + 8;
        int contentW = guiWidth - sidebarW - 20;
        int contentH = guiHeight - headerH - 16;

        graphics.enableScissor(contentX, contentY, contentX + contentW, contentY + contentH);

        List<Module> visibleModules = ModuleManager.getInstance().getModules().stream()
                .filter(m -> searchQuery.isEmpty() ? m.getCategory() == currentCategory :
                        m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                .collect(Collectors.toList());

        int currentY = contentY - scrollOffset;
        for (Module module : visibleModules) {
            int cardH = 38;
            if (module.isExpandedInGui() && !module.getSettings().isEmpty()) {
                cardH += module.getSettings().size() * 24 + 6;
            }

            boolean isHover = RenderUtils.isHovered(mouseX, mouseY, contentX, currentY, contentW, 38);

            // Karta modułu
            int cardBg = module.isToggled() ? 0xFF151922 : (isHover ? 0xFF14161C : 0xFF101216);
            int cardBorder = module.isToggled() ? 0xFF243044 : (isHover ? 0xFF222631 : 0xFF1A1C24);

            RenderUtils.drawRect(graphics, contentX, currentY, contentW, cardH, cardBg);
            RenderUtils.drawOutline(graphics, contentX, currentY, contentW, cardH, 1, cardBorder);

            if (module.isToggled()) {
                // Pasek akcentu po lewej stronie włączonego modułu
                RenderUtils.drawRect(graphics, contentX, currentY, 2, cardH, 0xFF00D2FF);
            }

            // Nazwa modułu
            int nameColor = module.isToggled() ? 0xFF00D2FF : 0xFFDEE3ED;
            graphics.drawString(this.font, module.getName(), contentX + 10, currentY + 9, nameColor, false);

            // Opis modułu
            graphics.drawString(this.font, module.getDescription(), contentX + 10, currentY + 22, 0xFF656D80, false);

            // Przycisk Bindu
            String keyText = (listeningModule == module) ? "..." : "[" + getKeyName(module.getKey()) + "]";
            int keyW = this.font.width(keyText) + 8;
            int keyX = contentX + contentW - 75 - keyW;
            int keyY = currentY + 10;
            boolean keyHover = RenderUtils.isHovered(mouseX, mouseY, keyX, keyY, keyW, 18);

            int keyBg = keyHover ? 0xFF1E222D : 0xFF13151C;
            RenderUtils.drawRect(graphics, keyX, keyY, keyW, 18, keyBg);
            RenderUtils.drawOutline(graphics, keyX, keyY, keyW, 18, 1, 0xFF262A36);
            int keyCol = (listeningModule == module) ? 0xFF00D2FF : 0xFF7C8599;
            graphics.drawString(this.font, keyText, keyX + 4, keyY + 5, keyCol, false);

            // Przycisk rozwijania ustawień (jeśli moduł ma ustawienia)
            if (!module.getSettings().isEmpty()) {
                int arrowX = contentX + contentW - 68;
                int arrowY = currentY + 14;
                String arrow = module.isExpandedInGui() ? "v" : ">";
                boolean arrowHover = RenderUtils.isHovered(mouseX, mouseY, arrowX - 4, arrowY - 4, 16, 16);
                graphics.drawString(this.font, arrow, arrowX, arrowY, arrowHover ? 0xFFFFFFFF : 0xFF677085, false);
            }

            // Przełącznik ON / OFF
            int switchW = 34;
            int switchH = 16;
            int switchX = contentX + contentW - 44;
            int switchY = currentY + 11;

            int switchBg = module.isToggled() ? 0xFF00D2FF : 0xFF1D2028;
            RenderUtils.drawRect(graphics, switchX, switchY, switchW, switchH, switchBg);
            RenderUtils.drawOutline(graphics, switchX, switchY, switchW, switchH, 1, module.isToggled() ? 0xFF00D2FF : 0xFF2A2F3D);

            int knobX = module.isToggled() ? (switchX + switchW - 14) : (switchX + 2);
            RenderUtils.drawRect(graphics, knobX, switchY + 2, 12, 12, 0xFFFFFFFF);

            // 4. Panel ustawień modułu (po rozwinięciu)
            if (module.isExpandedInGui() && !module.getSettings().isEmpty()) {
                int sY = currentY + 41;
                RenderUtils.drawRect(graphics, contentX + 6, sY - 2, contentW - 12, 1, 0xFF1B1E26);

                for (Setting setting : module.getSettings()) {
                    if (setting instanceof BooleanSetting bool) {
                        // Checkbox boolean
                        int cbX = contentX + 16;
                        int cbY = sY + 3;
                        int cbSize = 12;

                        RenderUtils.drawRect(graphics, cbX, cbY, cbSize, cbSize, bool.isEnabled() ? 0xFF00D2FF : 0xFF14161D);
                        RenderUtils.drawOutline(graphics, cbX, cbY, cbSize, cbSize, 1, bool.isEnabled() ? 0xFF00D2FF : 0xFF282D3B);
                        if (bool.isEnabled()) {
                            graphics.drawString(this.font, "x", cbX + 3, cbY + 2, 0xFF0D0E12, false);
                        }

                        graphics.drawString(this.font, bool.getName(), cbX + 18, cbY + 2, 0xFFC7CDDB, false);

                    } else if (setting instanceof NumberSetting num) {
                        // Suwak (Slider)
                        graphics.drawString(this.font, num.getName(), contentX + 16, sY + 5, 0xFFC7CDDB, false);

                        int sliderW = 110;
                        int sliderX = contentX + contentW - sliderW - 20;
                        int sliderY = sY + 7;
                        int sliderH = 6;

                        RenderUtils.drawRect(graphics, sliderX, sliderY, sliderW, sliderH, 0xFF161820);
                        RenderUtils.drawOutline(graphics, sliderX, sliderY, sliderW, sliderH, 1, 0xFF262B38);

                        float pct = (float) ((num.getValue() - num.getMin()) / (num.getMax() - num.getMin()));
                        pct = Math.max(0.0f, Math.min(1.0f, pct));
                        int filled = (int) (sliderW * pct);
                        if (filled > 0) {
                            RenderUtils.drawRect(graphics, sliderX, sliderY, filled, sliderH, 0xFF00D2FF);
                        }

                        // Wartość liczbowa
                        String valStr = String.valueOf(Math.round(num.getValue() * 100.0) / 100.0);
                        int valW = this.font.width(valStr);
                        graphics.drawString(this.font, valStr, sliderX - valW - 8, sY + 5, 0xFF7C8599, false);

                    } else if (setting instanceof ModeSetting mode) {
                        // Przełącznik trybu
                        graphics.drawString(this.font, mode.getName(), contentX + 16, sY + 5, 0xFFC7CDDB, false);

                        String mText = "< " + mode.getMode() + " >";
                        int mW = this.font.width(mText) + 8;
                        int mX = contentX + contentW - mW - 20;
                        int mY = sY + 3;

                        boolean mHover = RenderUtils.isHovered(mouseX, mouseY, mX, mY, mW, 14);
                        RenderUtils.drawRect(graphics, mX, mY, mW, 14, mHover ? 0xFF1B1E28 : 0xFF13151D);
                        RenderUtils.drawOutline(graphics, mX, mY, mW, 14, 1, 0xFF252A38);
                        graphics.drawString(this.font, mText, mX + 4, mY + 3, 0xFF00D2FF, false);
                    }
                    sY += 24;
                }
            }

            currentY += cardH + 6;
        }

        int totalH = currentY + scrollOffset - contentY;
        this.maxScroll = Math.max(0, totalH - contentH);

        graphics.disableScissor();

        // Pasek przewijania
        if (maxScroll > 0) {
            int sbX = contentX + contentW + 2;
            int sbH = contentH;
            RenderUtils.drawRect(graphics, sbX, contentY, 2, sbH, 0xFF14161C);

            float scrollPct = (float) scrollOffset / (float) maxScroll;
            int thumbH = Math.max(20, (int) ((float) contentH / totalH * contentH));
            int thumbY = contentY + (int) (scrollPct * (sbH - thumbH));
            RenderUtils.drawRect(graphics, sbX, thumbY, 2, thumbH, 0xFF00D2FF);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) { // Lewy klik
            // Wyszukiwarka
            int searchW = 140;
            int searchH = 20;
            int searchX = guiX + guiWidth - searchW - 14;
            int searchY = guiY + 9;

            if (!searchQuery.isEmpty() && RenderUtils.isHovered(mouseX, mouseY, searchX + searchW - 14, searchY + 3, 12, 14)) {
                this.searchQuery = "";
                this.scrollOffset = 0;
                return true;
            }
            this.searchFocused = RenderUtils.isHovered(mouseX, mouseY, searchX, searchY, searchW, searchH);

            // Zakładki kategorii
            int sidebarW = 125;
            int sidebarX = guiX;
            int sidebarY = guiY + 38;
            int catY = sidebarY + 8;
            for (Category category : Category.values()) {
                if (RenderUtils.isHovered(mouseX, mouseY, sidebarX + 6, catY, sidebarW - 12, 28)) {
                    this.currentCategory = category;
                    this.scrollOffset = 0;
                    this.searchQuery = "";
                    return true;
                }
                catY += 32;
            }

            // Moduły
            int contentX = guiX + sidebarW + 10;
            int contentY = guiY + 38 + 8;
            int contentW = guiWidth - sidebarW - 20;
            int contentH = guiHeight - 38 - 16;

            if (RenderUtils.isHovered(mouseX, mouseY, contentX, contentY, contentW, contentH)) {
                List<Module> visibleModules = ModuleManager.getInstance().getModules().stream()
                        .filter(m -> searchQuery.isEmpty() ? m.getCategory() == currentCategory :
                                m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                        .collect(Collectors.toList());

                int currentY = contentY - scrollOffset;
                for (Module module : visibleModules) {
                    int cardH = 38;
                    if (module.isExpandedInGui() && !module.getSettings().isEmpty()) {
                        cardH += module.getSettings().size() * 24 + 6;
                    }

                    // Przełącznik ON/OFF
                    int switchX = contentX + contentW - 44;
                    int switchY = currentY + 11;
                    if (RenderUtils.isHovered(mouseX, mouseY, switchX, switchY, 34, 16)) {
                        module.toggle();
                        return true;
                    }

                    // Keybind
                    String keyText = (listeningModule == module) ? "..." : "[" + getKeyName(module.getKey()) + "]";
                    int keyW = this.font.width(keyText) + 8;
                    int keyX = contentX + contentW - 75 - keyW;
                    int keyY = currentY + 10;
                    if (RenderUtils.isHovered(mouseX, mouseY, keyX, keyY, keyW, 18)) {
                        this.listeningModule = (this.listeningModule == module) ? null : module;
                        return true;
                    }

                    // Rozwijanie strzałką
                    if (!module.getSettings().isEmpty()) {
                        int arrowX = contentX + contentW - 68;
                        int arrowY = currentY + 10;
                        if (RenderUtils.isHovered(mouseX, mouseY, arrowX - 4, arrowY - 2, 16, 18)) {
                            module.toggleExpandedInGui();
                            return true;
                        }
                    }

                    // Kliknięcia w ustawienia
                    if (module.isExpandedInGui() && !module.getSettings().isEmpty()) {
                        int sY = currentY + 41;
                        for (Setting setting : module.getSettings()) {
                            if (setting instanceof BooleanSetting bool) {
                                int cbX = contentX + 16;
                                int cbY = sY + 3;
                                int cbW = this.font.width(bool.getName()) + 25;
                                if (RenderUtils.isHovered(mouseX, mouseY, cbX, cbY, cbW, 14)) {
                                    bool.toggle();
                                    return true;
                                }
                            } else if (setting instanceof NumberSetting num) {
                                int sliderW = 110;
                                int sliderX = contentX + contentW - sliderW - 20;
                                int sliderY = sY + 4;
                                if (RenderUtils.isHovered(mouseX, mouseY, sliderX - 4, sliderY, sliderW + 8, 14)) {
                                    this.draggingSlider = num;
                                    this.draggingSliderX = sliderX;
                                    this.draggingSliderWidth = sliderW;
                                    updateSliderValue(mouseX);
                                    return true;
                                }
                            } else if (setting instanceof ModeSetting mode) {
                                String mText = "< " + mode.getMode() + " >";
                                int mW = this.font.width(mText) + 8;
                                int mX = contentX + contentW - mW - 20;
                                int mY = sY + 3;
                                if (RenderUtils.isHovered(mouseX, mouseY, mX, mY, mW, 14)) {
                                    mode.cycle();
                                    if (module instanceof com.example.client.module.impl.HitSoundsModule hitSounds) {
                                        hitSounds.playSound();
                                    }
                                    return true;
                                }
                            }
                            sY += 24;
                        }
                    }

                    currentY += cardH + 6;
                }
            }
        } else if (button == 1) { // Prawy klik: rozwijanie modułu
            int sidebarW = 125;
            int contentX = guiX + sidebarW + 10;
            int contentY = guiY + 38 + 8;
            int contentW = guiWidth - sidebarW - 20;
            int contentH = guiHeight - 38 - 16;

            if (RenderUtils.isHovered(mouseX, mouseY, contentX, contentY, contentW, contentH)) {
                List<Module> visibleModules = ModuleManager.getInstance().getModules().stream()
                        .filter(m -> searchQuery.isEmpty() ? m.getCategory() == currentCategory :
                                m.getName().toLowerCase().contains(searchQuery.toLowerCase()))
                        .collect(Collectors.toList());

                int currentY = contentY - scrollOffset;
                for (Module module : visibleModules) {
                    int cardH = 38;
                    if (module.isExpandedInGui() && !module.getSettings().isEmpty()) {
                        cardH += module.getSettings().size() * 24 + 6;
                    }

                    if (RenderUtils.isHovered(mouseX, mouseY, contentX, currentY, contentW, 38)) {
                        if (!module.getSettings().isEmpty()) {
                            module.toggleExpandedInGui();
                            return true;
                        }
                    }
                    currentY += cardH + 6;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) {
            this.draggingSlider = null;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0 && this.draggingSlider != null) {
            updateSliderValue(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    private void updateSliderValue(double mouseX) {
        if (draggingSlider != null && draggingSliderWidth > 0) {
            double diff = Math.min(draggingSliderWidth, Math.max(0, mouseX - draggingSliderX));
            double percent = diff / (double) draggingSliderWidth;
            double min = draggingSlider.getMin();
            double max = draggingSlider.getMax();
            double newValue = min + (percent * (max - min));
            draggingSlider.setValue(newValue);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount != 0) {
            this.scrollOffset -= (int) (verticalAmount * 24);
            this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.maxScroll));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (this.listeningModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE) {
                this.listeningModule.setKey(GLFW.GLFW_KEY_UNKNOWN);
            } else {
                this.listeningModule.setKey(keyCode);
            }
            this.listeningModule = null;
            return true;
        }

        if (searchFocused) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !searchQuery.isEmpty()) {
                searchQuery = searchQuery.substring(0, searchQuery.length() - 1);
                scrollOffset = 0;
                return true;
            } else if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_ESCAPE) {
                searchFocused = false;
                return true;
            }
        }

        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            this.onClose();
            return true;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (searchFocused) {
            searchQuery += codePoint;
            scrollOffset = 0;
            return true;
        }
        return super.charTyped(codePoint, modifiers);
    }

    public static String getKeyName(int keyCode) {
        if (keyCode <= 0 || keyCode == GLFW.GLFW_KEY_UNKNOWN) return "NONE";
        String name = GLFW.glfwGetKeyName(keyCode, 0);
        if (name != null && !name.isEmpty()) {
            return name.toUpperCase();
        }
        return switch (keyCode) {
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_ENTER -> "ENTER";
            default -> "KEY " + keyCode;
        };
    }
}
